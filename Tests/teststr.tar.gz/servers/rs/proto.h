/* Function prototypes. */

/* sm.c */
_PROTOTYPE( int main, (void));

/* manager.c */
_PROTOTYPE( int do_exit, (message *m));
_PROTOTYPE( int do_start, (message *m));
_PROTOTYPE( int do_stop, (message *m));


